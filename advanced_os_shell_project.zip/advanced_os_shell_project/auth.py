import json
import os

DEFAULT_USERS = {
    "admin": {"password": "admin123", "role": "admin"},
    "user1": {"password": "password1", "role": "standard"},
}

class AuthManager:
    def __init__(self, db_path="users.json"):
        self.db_path = db_path
        self.users = self._load_users()
        self.current_user = None

    def _load_users(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict) and data:
                        return data
            except Exception:
                pass
        with open(self.db_path, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_USERS, f, indent=2)
        return DEFAULT_USERS.copy()

    def login(self, username, password):
        user = self.users.get(username)
        if not user or user.get("password") != password:
            return False, "Invalid username or password"
        self.current_user = {
            "username": username,
            "role": user.get("role", "standard")
        }
        return True, f"Login successful\nWelcome {username}"

    def logout(self):
        self.current_user = None
        return "Logged out"

    def require_login(self):
        return self.current_user is not None

    def role(self):
        if not self.current_user:
            return None
        return self.current_user.get("role")

    def username(self):
        if not self.current_user:
            return None
        return self.current_user.get("username")
