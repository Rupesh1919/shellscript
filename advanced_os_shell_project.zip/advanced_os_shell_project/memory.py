import threading
import time
import random

class Frame:
    def __init__(self, process_id, page, loaded_time):
        self.process_id = process_id
        self.page = page
        self.loaded_time = loaded_time
        self.last_used = loaded_time

class MemoryManager:
    def __init__(self, frame_count=3):
        self.frame_count = frame_count
        self.memory = []
        self.page_faults = 0
        self.time_counter = 0
        self.process_page_usage = {}

    def reset(self):
        self.memory.clear()
        self.page_faults = 0
        self.time_counter = 0
        self.process_page_usage.clear()
        return "Memory state cleared."

    def print_memory(self):
        if not self.memory:
            return "Current Memory Frames:\n<empty>"
        lines = ["Current Memory Frames:"]
        for i, frame in enumerate(self.memory):
            lines.append(
                f"Frame {i}: Process {frame.process_id} Page {frame.page} "
                f"(loaded={frame.loaded_time}, last_used={frame.last_used})"
            )
        return "\n".join(lines)

    def fifo_replace(self):
        return min(self.memory, key=lambda x: x.loaded_time)

    def lru_replace(self):
        return min(self.memory, key=lambda x: x.last_used)

    def request_page(self, process_id, page, algorithm="FIFO"):
        self.time_counter += 1
        self.process_page_usage.setdefault(process_id, set()).add(page)

        for frame in self.memory:
            if frame.process_id == process_id and frame.page == page:
                frame.last_used = self.time_counter
                return (
                    f"Process {process_id} accessed Page {page} (Already in memory)\n"
                    + self.print_memory()
                )

        lines = [f"PAGE FAULT: Process {process_id} requested Page {page}"]
        self.page_faults += 1
        if len(self.memory) < self.frame_count:
            self.memory.append(Frame(process_id, page, self.time_counter))
            lines.append(f"Loaded Page {page} of Process {process_id} into memory")
        else:
            if algorithm.upper() == "FIFO":
                victim = self.fifo_replace()
                lines.append(f"FIFO replacing Process {victim.process_id} Page {victim.page}")
            else:
                victim = self.lru_replace()
                lines.append(f"LRU replacing Process {victim.process_id} Page {victim.page}")
            self.memory.remove(victim)
            self.memory.append(Frame(process_id, page, self.time_counter))
        lines.append(self.print_memory())
        return "\n".join(lines)

    def status(self):
        lines = [self.print_memory(), f"Total Page Faults: {self.page_faults}"]
        if self.process_page_usage:
            lines.append("Per-Process Page Usage:")
            for pid, pages in sorted(self.process_page_usage.items()):
                lines.append(f"  Process {pid}: {len(pages)} page(s) -> {sorted(pages)}")
        return "\n".join(lines)

    def demo(self):
        lines = ["============================",
                 " MEMORY MANAGEMENT (FIFO)",
                 "============================"]
        requests = [(1,1),(1,2),(2,1),(1,3),(2,2),(1,4)]
        for p, page in requests:
            lines.append(self.request_page(p, page, "FIFO"))
        lines.append(f"Total Page Faults (FIFO): {self.page_faults}")
        self.reset()
        lines.extend(["============================", " MEMORY MANAGEMENT (LRU)", "============================"])
        for p, page in requests:
            lines.append(self.request_page(p, page, "LRU"))
        lines.append(f"Total Page Faults (LRU): {self.page_faults}")
        return "\n".join(lines)

class SyncManager:
    def __init__(self, buffer_size=5):
        self.buffer_size = buffer_size
        self.reset()

    def reset(self):
        self.buffer = []
        self.mutex = threading.Semaphore(1)
        self.empty = threading.Semaphore(self.buffer_size)
        self.full = threading.Semaphore(0)
        self.logs = []

    def producer(self):
        for _ in range(5):
            item = random.randint(1, 100)
            self.empty.acquire()
            self.mutex.acquire()
            self.buffer.append(item)
            self.logs.append(f"Producer produced {item} | Buffer: {self.buffer.copy()}")
            self.mutex.release()
            self.full.release()
            time.sleep(0.05)

    def consumer(self):
        for _ in range(5):
            self.full.acquire()
            self.mutex.acquire()
            item = self.buffer.pop(0)
            self.logs.append(f"Consumer consumed {item} | Buffer: {self.buffer.copy()}")
            self.mutex.release()
            self.empty.release()
            time.sleep(0.05)

    def demo(self):
        self.reset()
        p = threading.Thread(target=self.producer)
        c = threading.Thread(target=self.consumer)
        p.start()
        c.start()
        p.join()
        c.join()
        return "\n".join(["============================", " PRODUCER CONSUMER DEMO", "============================"] + self.logs + ["Execution Complete"])
