import os
import signal

jobs = {}
job_counter = 1

def clean_finished_jobs():
    finished = []
    for jid, pid in list(jobs.items()):
        try:
            result = os.waitpid(pid, os.WNOHANG)
            if result[0] != 0:
                finished.append(jid)
        except ChildProcessError:
            finished.append(jid)
    for jid in finished:
        del jobs[jid]

def execute_external_command(args, background=False):
    global job_counter
    pid = os.fork()
    if pid == 0:
        try:
            os.execvp(args[0], args)
        except FileNotFoundError:
            print(f"Command not found: {args[0]}")
            os._exit(1)
    else:
        if background:
            jobs[job_counter] = pid
            print(f"[{job_counter}] started with PID {pid}")
            job_counter += 1
        else:
            os.waitpid(pid, 0)

def jobs_text():
    if not jobs:
        return "No background jobs"
    lines = []
    for jid, pid in jobs.items():
        try:
            result = os.waitpid(pid, os.WNOHANG)
            if result[0] == 0:
                lines.append(f"[{jid}] PID:{pid} Running")
            else:
                lines.append(f"[{jid}] PID:{pid} Finished")
        except ChildProcessError:
            lines.append(f"[{jid}] PID:{pid} Finished")
    return "\n".join(lines)

def bring_fg(jid):
    jid = int(jid)
    if jid not in jobs:
        return "fg: No such job"
    pid = jobs[jid]
    os.waitpid(pid, 0)
    del jobs[jid]
    return f"Bringing job [{jid}] to foreground"

def bg_text(jid):
    jid = int(jid)
    if jid not in jobs:
        return "bg: No such job"
    pid = jobs[jid]
    return f"Job [{jid}] running in background PID {pid}"

def kill_pid(pid):
    pid = int(pid)
    os.kill(pid, signal.SIGTERM)
    for jid, jpid in list(jobs.items()):
        if jpid == pid:
            del jobs[jid]
    return f"Process {pid} terminated"
