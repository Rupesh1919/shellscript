import time
import heapq
from collections import deque

class SimProcess:
    def __init__(self, pid, name, burst_time, priority=0, arrival_order=0):
        self.pid = pid
        self.name = name
        self.burst_time = burst_time
        self.remaining_time = burst_time
        self.priority = priority
        self.arrival_order = arrival_order
        self.start_time = None
        self.finish_time = None
        self.response_time = None
        self.waiting_time = 0
        self.turnaround_time = 0

    def __repr__(self):
        return (
            f"PID={self.pid}, Name={self.name}, Burst={self.burst_time}, "
            f"Remaining={self.remaining_time}, Priority={self.priority}"
        )

class Scheduler:
    def __init__(self):
        self.reset()

    def reset(self):
        self.rr_queue = deque()
        self.priority_queue = []
        self.completed = []
        self.sim_pid_counter = 1
        self.arrival_counter = 0

    def add_rr_process(self, name, burst_time):
        p = SimProcess(
            pid=self.sim_pid_counter,
            name=name,
            burst_time=burst_time,
            arrival_order=self.arrival_counter
        )
        self.rr_queue.append(p)
        self.sim_pid_counter += 1
        self.arrival_counter += 1
        return f"Added RR process -> {p}"

    def add_priority_process(self, name, burst_time, priority):
        p = SimProcess(
            pid=self.sim_pid_counter,
            name=name,
            burst_time=burst_time,
            priority=priority,
            arrival_order=self.arrival_counter
        )
        heapq.heappush(self.priority_queue, (priority, self.arrival_counter, p))
        self.sim_pid_counter += 1
        self.arrival_counter += 1
        return f"Added Priority process -> {p}"

    def show_rr_queue(self):
        if not self.rr_queue:
            return "Round-Robin queue is empty."
        lines = ["Round-Robin Queue:"]
        for p in self.rr_queue:
            lines.append(f"  {p}")
        return "\n".join(lines)

    def show_priority_queue(self):
        if not self.priority_queue:
            return "Priority queue is empty."
        lines = ["Priority Queue:"]
        for prio, order, p in sorted(self.priority_queue, key=lambda x: (x[0], x[1])):
            lines.append(
                f"  PID={p.pid}, Name={p.name}, Burst={p.burst_time}, "
                f"Remaining={p.remaining_time}, Priority={p.priority}"
            )
        return "\n".join(lines)

    def run_round_robin(self, quantum, sleep_unit=0.05):
        if not self.rr_queue:
            return "No Round-Robin processes to schedule."
        lines = [f"Starting Round-Robin Scheduling with quantum = {quantum}"]
        current_time = 0
        completed_local = []
        while self.rr_queue:
            process = self.rr_queue.popleft()
            if process.start_time is None:
                process.start_time = current_time
                process.response_time = process.start_time
            run_time = min(quantum, process.remaining_time)
            lines.append(
                f"Running Process PID={process.pid}, Name={process.name}, "
                f"for {run_time} unit(s). Remaining before run = {process.remaining_time}"
            )
            time.sleep(run_time * sleep_unit)
            process.remaining_time -= run_time
            current_time += run_time
            if process.remaining_time == 0:
                process.finish_time = current_time
                process.turnaround_time = process.finish_time
                process.waiting_time = process.turnaround_time - process.burst_time
                completed_local.append(process)
                lines.append(
                    f"Completed Process PID={process.pid}, Name={process.name}, "
                    f"Finish Time={process.finish_time}"
                )
            else:
                lines.append(
                    f"Time slice expired for PID={process.pid}, Name={process.name}. "
                    f"Remaining Time={process.remaining_time}. Moving to back of queue."
                )
                self.rr_queue.append(process)
            lines.append("-" * 60)
        self.completed.extend(completed_local)
        lines.append(self.metrics_text(completed_local, "Round-Robin"))
        return "\n".join(lines)

    def run_priority_preemptive(self, sleep_unit=0.05):
        if not self.priority_queue:
            return "No Priority processes to schedule."
        lines = ["Starting Preemptive Priority Scheduling"]
        current_time = 0
        completed_local = []
        while self.priority_queue:
            priority, arrival_order, process = heapq.heappop(self.priority_queue)
            if process.start_time is None:
                process.start_time = current_time
                process.response_time = process.start_time
            lines.append(
                f"Running Process PID={process.pid}, Name={process.name}, "
                f"Priority={process.priority}, Remaining={process.remaining_time}"
            )
            time.sleep(1 * sleep_unit)
            process.remaining_time -= 1
            current_time += 1
            if process.remaining_time == 0:
                process.finish_time = current_time
                process.turnaround_time = process.finish_time
                process.waiting_time = process.turnaround_time - process.burst_time
                completed_local.append(process)
                lines.append(
                    f"Completed Process PID={process.pid}, Name={process.name}, "
                    f"Finish Time={process.finish_time}"
                )
            else:
                lines.append(
                    f"Preempting/Re-queueing PID={process.pid}, Name={process.name}, "
                    f"Remaining={process.remaining_time}"
                )
                heapq.heappush(
                    self.priority_queue,
                    (process.priority, process.arrival_order, process)
                )
            lines.append("-" * 60)
        self.completed.extend(completed_local)
        lines.append(self.metrics_text(completed_local, "Priority-Based Scheduling"))
        return "\n".join(lines)

    def metrics_text(self, processes, algorithm_name):
        if not processes:
            return f"No completed processes for {algorithm_name}."
        lines = [f"Performance Metrics for {algorithm_name}", "=" * 72]
        lines.append(
            f"{'PID':<8}{'Name':<15}{'Burst':<10}{'Priority':<10}"
            f"{'Waiting':<12}{'Turnaround':<14}{'Response':<10}"
        )
        total_waiting = total_turnaround = total_response = 0
        for p in processes:
            total_waiting += p.waiting_time
            total_turnaround += p.turnaround_time
            total_response += p.response_time
            lines.append(
                f"{p.pid:<8}{p.name:<15}{p.burst_time:<10}{p.priority:<10}"
                f"{p.waiting_time:<12}{p.turnaround_time:<14}{p.response_time:<10}"
            )
        n = len(processes)
        lines.append("=" * 72)
        lines.append(f"Average Waiting Time   : {total_waiting / n:.2f}")
        lines.append(f"Average Turnaround Time: {total_turnaround / n:.2f}")
        lines.append(f"Average Response Time  : {total_response / n:.2f}")
        return "\n".join(lines)

    def show_completed(self):
        if not self.completed:
            return "No completed scheduled processes."
        lines = ["Completed Scheduled Processes:"]
        for p in self.completed:
            lines.append(
                f"PID={p.pid}, Name={p.name}, Burst={p.burst_time}, "
                f"Priority={p.priority}, Waiting={p.waiting_time}, "
                f"Turnaround={p.turnaround_time}, Response={p.response_time}"
            )
        return "\n".join(lines)
