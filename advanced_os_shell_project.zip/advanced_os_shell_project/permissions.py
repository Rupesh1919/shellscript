import json
import os

DEFAULT_FILE_PERMISSIONS = {
    "system.log": {
        "owner": "admin",
        "permissions": {"admin": "rw", "standard": "r"}
    },
    "notes.txt": {
        "owner": "user1",
        "permissions": {"admin": "rw", "standard": "rw"}
    },
    "script.sh": {
        "owner": "admin",
        "permissions": {"admin": "rwx", "standard": "rx"}
    },
    "error.log": {
        "owner": "admin",
        "permissions": {"admin": "rw", "standard": "r"}
    }
}

class PermissionManager:
    def __init__(self, db_path="permissions.json"):
        self.db_path = db_path
        self.permissions = self._load_permissions()

    def _load_permissions(self):
        if os.path.exists(self.db_path):
            try:
                with open(self.db_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if isinstance(data, dict):
                        return data
            except Exception:
                pass
        with open(self.db_path, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_FILE_PERMISSIONS, f, indent=2)
        return DEFAULT_FILE_PERMISSIONS.copy()

    def save(self):
        with open(self.db_path, "w", encoding="utf-8") as f:
            json.dump(self.permissions, f, indent=2)

    def ensure_file_entry(self, filename, owner="admin"):
        if filename not in self.permissions:
            self.permissions[filename] = {
                "owner": owner,
                "permissions": {"admin": "rw", "standard": "r"}
            }
            self.save()

    def can_access(self, role, filename, mode):
        info = self.permissions.get(filename)
        if not info:
            return True
        allowed = info.get("permissions", {}).get(role, "")
        return mode in allowed

    def chmod(self, filename, role_name, perms, acting_role):
        if acting_role != "admin":
            return False, "Permission denied: admin access required"
        self.ensure_file_entry(filename)
        self.permissions[filename]["permissions"][role_name] = perms
        self.save()
        return True, f"Permissions updated: {filename} -> {role_name}:{perms}"

    def describe(self, filename):
        info = self.permissions.get(filename)
        if not info:
            return f"{filename}: no explicit simulated permissions"
        return f"{filename}: owner={info['owner']} permissions={info['permissions']}"
