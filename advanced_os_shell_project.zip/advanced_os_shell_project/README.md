# Advanced Shell Simulation with Integrated OS Concepts - Deliverable 4

## Files
- `shell.py` - main integrated shell
- `auth.py` - login and role handling
- `permissions.py` - simulated Unix-style file permissions
- `piping.py` - multi-stage pipeline executor
- `scheduler.py` - Round-Robin and Priority scheduling
- `memory.py` - paging, FIFO/LRU, and producer-consumer synchronization
- `process.py` - background process support
- `integrated_deliverable4.py` - launcher entry point

## Run
```bash
cd advanced_os_shell_project
python3 integrated_deliverable4.py
```

## Default Credentials
- admin / admin123
- user1 / password1

## Important Commands
```bash
help
paging fifo
paging lru
memory_status
sync_demo
rr_add p1 3
rr_run 2
prio_add p2 4 1
prio_run
cat error.log | grep ERROR | sort
chmod_sim system.log standard r
perms system.log
```

## Sample Git Commands
```bash
git init
git add .
git commit -m "Deliverable 4 shell integration"
git remote add origin https://github.com/<username>/advanced-os-shell
git push origin main
```
