import os
import sys
import shlex
import getpass

from auth import AuthManager
from permissions import PermissionManager
from scheduler import Scheduler
from memory import MemoryManager, SyncManager
from process import (
    clean_finished_jobs,
    execute_external_command,
    jobs_text,
    bring_fg,
    bg_text,
    kill_pid,
)
from piping import execute_pipeline

auth = AuthManager()
perms = PermissionManager()
scheduler = Scheduler()
memory_manager = MemoryManager()
sync_manager = SyncManager()

def seed_demo_files():
    demo_files = {
        "system.log": "SYSTEM START\nOnly admin should update this file.\n",
        "notes.txt": "class notes\nerror handling\nscheduling and paging\n",
        "script.sh": "#!/bin/bash\necho demo script\n",
        "error.log": "ERROR: network timeout\nINFO: retrying\nERROR: file missing\n",
    }
    for filename, content in demo_files.items():
        if not os.path.exists(filename):
            with open(filename, "w", encoding="utf-8") as f:
                f.write(content)
        perms.ensure_file_entry(filename, owner="admin" if filename != "notes.txt" else "user1")

def print_help():
    print("""
Available Commands
------------------
Core Shell:
  pwd
  cd <directory>
  echo <text>
  clear
  ls
  cat <file>
  mkdir <directory>
  rmdir <directory>
  rm <file>
  touch <file>
  write <file> <text>
  append <file> <text>
  jobs
  fg <job_id>
  bg <job_id>
  kill <pid>
  exit

Authentication & Security:
  login
  login <username>
  logout
  whoami
  chmod_sim <file> <admin|standard> <perms>
  perms <file>

Piping:
  ls | grep txt
  cat error.log | grep ERROR | sort
  echo hello world | grep hello

Scheduling:
  sched_help
  sched_reset
  rr_add <name> <burst_time>
  rr_show
  rr_run <quantum>
  prio_add <name> <burst_time> <priority>
  prio_show
  prio_run
  sched_completed

Memory & Synchronization:
  paging fifo
  paging lru
  page_request <process_id> <page_no>
  memory_status
  memory_reset
  sync_demo
  demo

Integration Examples:
  run_process process1
  schedule_rr
""".strip())

def print_scheduler_help():
    print("""
Scheduler Commands:
  rr_add <name> <burst_time>
  rr_show
  rr_run <quantum>
  prio_add <name> <burst_time> <priority>
  prio_show
  prio_run
  sched_completed
  sched_reset

Deliverable 3 / 4 Commands:
  paging fifo
  paging lru
  page_request <process_id> <page_no>
  memory_status
  memory_reset
  sync_demo
  demo
""".strip())

def require_auth():
    if not auth.require_login():
        print("Access denied: please log in first")
        return False
    return True

def require_permission(filename, mode):
    role = auth.role()
    if not perms.can_access(role, filename, mode):
        action = {"r": "read", "w": "write", "x": "execute"}.get(mode, mode)
        print(f"Permission denied: {action} access required")
        return False
    return True

def do_pwd(args, piped_input=None):
    return os.getcwd()

def do_echo(args, piped_input=None):
    return " ".join(args)

def do_whoami(args, piped_input=None):
    if not auth.current_user:
        return "No user logged in"
    return f"{auth.username()} ({auth.role()})"

def do_perms(args, piped_input=None):
    if len(args) < 1:
        return "Usage: perms <file>"
    return perms.describe(args[0])

PIPE_BUILTINS = {
    "pwd": do_pwd,
    "echo": do_echo,
    "whoami": do_whoami,
    "perms": do_perms,
}

def interactive_login(username=None):
    if username is None:
        username = input("Login: ").strip()
    password = getpass.getpass("Password: ")
    ok, msg = auth.login(username, password)
    print(msg)

def run_shell():
    seed_demo_files()
    print("Advanced OS Shell Simulation Loaded.")
    print("Login required before using the shell.")
    interactive_login()

    while True:
        clean_finished_jobs()
        try:
            prompt_user = auth.username() if auth.username() else "guest"
            command_input = input(f"{prompt_user}@myshell> ")
            if not command_input.strip():
                continue

            if "|" in command_input:
                if not require_auth():
                    continue
                output = execute_pipeline(command_input, PIPE_BUILTINS)
                if output:
                    print(output)
                continue

            args = shlex.split(command_input)
            cmd = args[0]

            if cmd == "help":
                print_help()

            elif cmd == "login":
                if len(args) >= 2:
                    interactive_login(args[1])
                else:
                    interactive_login()

            elif cmd == "logout":
                print(auth.logout())

            elif cmd == "whoami":
                print(do_whoami(args[1:]))

            elif cmd == "exit":
                print("Exiting shell...")
                sys.exit(0)

            else:
                if not require_auth():
                    continue

                if cmd == "pwd":
                    print(os.getcwd())

                elif cmd == "cd":
                    if len(args) < 2:
                        print("cd: missing argument")
                    else:
                        try:
                            os.chdir(args[1])
                        except FileNotFoundError:
                            print("cd: directory not found")

                elif cmd == "echo":
                    print(" ".join(args[1:]))

                elif cmd == "clear":
                    os.system("clear")

                elif cmd == "ls":
                    print("\n".join(sorted(os.listdir("."))))

                elif cmd == "cat":
                    if len(args) < 2:
                        print("cat: missing filename")
                    else:
                        filename = args[1]
                        if require_permission(filename, "r"):
                            try:
                                with open(filename, "r", encoding="utf-8") as f:
                                    content = f.read()
                                    print(content, end="" if content.endswith("\n") else "\n")
                            except Exception as e:
                                print(f"cat error: {e}")

                elif cmd == "mkdir":
                    if len(args) < 2:
                        print("mkdir: missing directory name")
                    else:
                        try:
                            os.mkdir(args[1])
                        except Exception as e:
                            print(f"mkdir error: {e}")

                elif cmd == "rmdir":
                    if len(args) < 2:
                        print("rmdir: missing directory name")
                    else:
                        try:
                            os.rmdir(args[1])
                        except Exception as e:
                            print(f"rmdir error: {e}")

                elif cmd == "rm":
                    if len(args) < 2:
                        print("rm: missing filename")
                    else:
                        if require_permission(args[1], "w"):
                            try:
                                os.remove(args[1])
                            except Exception as e:
                                print(f"rm error: {e}")

                elif cmd == "touch":
                    if len(args) < 2:
                        print("touch: missing filename")
                    else:
                        filename = args[1]
                        if require_permission(filename, "w") if os.path.exists(filename) else True:
                            try:
                                open(filename, "a", encoding="utf-8").close()
                                perms.ensure_file_entry(filename, owner=auth.username() or "admin")
                            except Exception as e:
                                print(f"touch error: {e}")

                elif cmd == "write":
                    if len(args) < 3:
                        print("Usage: write <file> <text>")
                    else:
                        filename = args[1]
                        if require_permission(filename, "w"):
                            try:
                                with open(filename, "w", encoding="utf-8") as f:
                                    f.write(" ".join(args[2:]) + "\n")
                                print(f"Wrote to {filename}")
                            except Exception as e:
                                print(f"write error: {e}")

                elif cmd == "append":
                    if len(args) < 3:
                        print("Usage: append <file> <text>")
                    else:
                        filename = args[1]
                        if require_permission(filename, "w"):
                            try:
                                with open(filename, "a", encoding="utf-8") as f:
                                    f.write(" ".join(args[2:]) + "\n")
                                print(f"Appended to {filename}")
                            except Exception as e:
                                print(f"append error: {e}")

                elif cmd == "chmod_sim":
                    if len(args) != 4:
                        print("Usage: chmod_sim <file> <admin|standard> <perms>")
                    else:
                        ok, msg = perms.chmod(args[1], args[2], args[3], auth.role())
                        print(msg)

                elif cmd == "perms":
                    if len(args) < 2:
                        print("Usage: perms <file>")
                    else:
                        print(perms.describe(args[1]))

                elif cmd == "kill":
                    if len(args) < 2:
                        print("kill: missing PID")
                    else:
                        try:
                            print(kill_pid(args[1]))
                        except Exception as e:
                            print(f"kill error: {e}")

                elif cmd == "jobs":
                    print(jobs_text())

                elif cmd == "fg":
                    if len(args) < 2:
                        print("fg: missing job id")
                    else:
                        try:
                            print(bring_fg(args[1]))
                        except Exception as e:
                            print(f"fg error: {e}")

                elif cmd == "bg":
                    if len(args) < 2:
                        print("bg: missing job id")
                    else:
                        try:
                            print(bg_text(args[1]))
                        except Exception as e:
                            print(f"bg error: {e}")

                elif cmd == "sched_help":
                    print_scheduler_help()

                elif cmd == "sched_reset":
                    scheduler.reset()
                    print("Scheduler state cleared.")

                elif cmd == "rr_add":
                    if len(args) != 3:
                        print("Usage: rr_add <name> <burst_time>")
                    else:
                        try:
                            burst = int(args[2])
                            if burst <= 0:
                                print("burst_time must be > 0")
                            else:
                                print(scheduler.add_rr_process(args[1], burst))
                        except ValueError:
                            print("burst_time must be an integer")

                elif cmd == "rr_show":
                    print(scheduler.show_rr_queue())

                elif cmd == "rr_run":
                    if len(args) != 2:
                        print("Usage: rr_run <quantum>")
                    else:
                        try:
                            quantum = int(args[1])
                            if quantum <= 0:
                                print("quantum must be > 0")
                            else:
                                print(scheduler.run_round_robin(quantum))
                        except ValueError:
                            print("quantum must be an integer")

                elif cmd == "prio_add":
                    if len(args) != 4:
                        print("Usage: prio_add <name> <burst_time> <priority>")
                    else:
                        try:
                            burst = int(args[2]); priority = int(args[3])
                            if burst <= 0:
                                print("burst_time must be > 0")
                            else:
                                print(scheduler.add_priority_process(args[1], burst, priority))
                        except ValueError:
                            print("burst_time and priority must be integers")

                elif cmd == "prio_show":
                    print(scheduler.show_priority_queue())

                elif cmd == "prio_run":
                    print(scheduler.run_priority_preemptive())

                elif cmd == "sched_completed":
                    print(scheduler.show_completed())

                elif cmd == "paging":
                    if len(args) != 2 or args[1].lower() not in ("fifo", "lru"):
                        print("Usage: paging <fifo|lru>")
                    else:
                        memory_manager.reset()
                        requests = [(1,1),(1,2),(2,1),(1,3),(2,2),(1,4)]
                        for p, page in requests:
                            print(memory_manager.request_page(p, page, args[1].upper()))
                        print(f"Total Page Faults ({args[1].upper()}): {memory_manager.page_faults}")

                elif cmd == "page_request":
                    if len(args) != 3:
                        print("Usage: page_request <process_id> <page_no>")
                    else:
                        try:
                            process_id = int(args[1]); page_no = int(args[2])
                            print(memory_manager.request_page(process_id, page_no, "LRU"))
                        except ValueError:
                            print("process_id and page_no must be integers")

                elif cmd == "memory_status":
                    print(memory_manager.status())

                elif cmd == "memory_reset":
                    print(memory_manager.reset())

                elif cmd == "sync_demo":
                    print(sync_manager.demo())

                elif cmd == "demo":
                    print(memory_manager.demo())
                    print(sync_manager.demo())

                elif cmd == "run_process":
                    if len(args) != 2:
                        print("Usage: run_process <name>")
                    else:
                        print(scheduler.add_rr_process(args[1], 3))

                elif cmd == "schedule_rr":
                    if not scheduler.rr_queue:
                        print("No Round-Robin processes to schedule.")
                    else:
                        print(scheduler.run_round_robin(2))

                else:
                    background = False
                    if args[-1] == "&":
                        background = True
                        args = args[:-1]
                    execute_external_command(args, background)

        except KeyboardInterrupt:
            print("\\nCtrl+C detected")
        except EOFError:
            print("\\nExiting shell...")
            break
        except Exception as e:
            print(f"Shell error: {e}")

if __name__ == "__main__":
    run_shell()
