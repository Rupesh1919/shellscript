#!/bin/bash
echo demo script
