import os

def _sort_lines(lines):
    return "\n".join(sorted([line for line in lines.splitlines() if line.strip()]))

def _grep_lines(lines, pattern):
    return "\n".join([line for line in lines.splitlines() if pattern in line])

def _cat_file(filename):
    if not os.path.exists(filename):
        raise FileNotFoundError(f"cat: file not found: {filename}")
    with open(filename, "r", encoding="utf-8") as f:
        return f.read()

def _ls_dir(path="."):
    items = sorted(os.listdir(path))
    return "\n".join(items)

def execute_pipeline(command_input, shell_builtins):
    stages = [stage.strip() for stage in command_input.split("|") if stage.strip()]
    if not stages:
        return ""
    data = None

    for stage in stages:
        parts = stage.split()
        cmd = parts[0]
        args = parts[1:]

        if cmd == "grep":
            if not args:
                return "grep: missing search text"
            data = _grep_lines(data or "", " ".join(args))
        elif cmd == "sort":
            data = _sort_lines(data or "")
        elif cmd == "cat":
            if not args:
                return "cat: missing filename"
            try:
                data = _cat_file(args[0])
            except Exception as e:
                return str(e)
        elif cmd == "ls":
            path = args[0] if args else "."
            try:
                data = _ls_dir(path)
            except Exception as e:
                return f"ls error: {e}"
        elif cmd == "echo":
            data = " ".join(args)
        elif cmd in shell_builtins:
            result = shell_builtins[cmd](args, piped_input=data)
            data = result if result is not None else ""
        else:
            return f"Pipeline command not supported: {cmd}"

    return data or ""
